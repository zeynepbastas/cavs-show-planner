from pathlib import Path
import itertools
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'broad_results'
OUT.mkdir(exist_ok=True)
events = pd.read_csv(ROOT/'data/historical_events.csv')
upcoming = pd.read_csv(ROOT/'data/upcoming_events.csv')
demos = pd.read_csv(ROOT/'data/performer_demographic_profile.csv')
items = pd.read_csv(ROOT/'data/concessions_top5_overall_by_event.csv')
all_events = pd.concat([events,upcoming],ignore_index=True)
Ydf = items.pivot(index='event_id',columns='item_name',values='units_sold').reindex(events.event_id)
Y = Ydf.to_numpy(float)
N = events.tickets_sold.to_numpy(float)
acts, act_codes = np.unique(events.performer_id,return_inverse=True)
n = len(events)
definitions = {
 'under35':('age_bucket',['<25','25-34']),
 'age35to54':('age_bucket',['35-44','45-54']),
 'age55plus':('age_bucket',['55-64','65+']),
 'age65plus':('age_bucket',['65+']),
 'male':('gender',['M']),
 'children':('has_children',['Yes']),
 'married':('marital_status',['M']),
 'homeowner':('home_ownership',['HOME OWNER']),
 'income_above100k':('income',['$101K - $250K','$251K - $500K','$501K - $1M','>$1M']),
 'income_above250k':('income',['$251K - $500K','$501K - $1M','>$1M']),
 'wealth_above1m':('wealth',['$1M-$2M','$2M-$5M','$5M-$10M','$10M-$20M','$20M-$50M','>$50M']),
 'wealth_above500k':('wealth',['$500K-$1M','$1M-$2M','$2M-$5M','$5M-$10M','$10M-$20M','$20M-$50M','>$50M']),
 'bachelors_or_more':('education',['BACHELORS','MASTERS','DOCTORATE','POSTGRADUATE']),
 'postgraduate':('education',['MASTERS','DOCTORATE','POSTGRADUATE']),
}
features = {}
for name,(dim,values) in definitions.items():
    d = demos[demos.dimension.eq(dim)]
    total = d.groupby('performer_id').buyer_count.sum()
    count = d[d.value.isin(values)].groupby('performer_id').buyer_count.sum().reindex(total.index,fill_value=0)
    features[name] = all_events.performer_id.map(count/total).to_numpy()
features['older_without_children_score'] = (features['age55plus']+1-features['children'])/2
features['affluence_score'] = (features['income_above100k']+features['wealth_above1m'])/2
features['young_with_children_score'] = (features['under35']+features['children'])/2
features['married_homeowner_score'] = (features['married']+features['homeowner'])/2
schemes, seen = [],set()

def add(name,family,labels,rule):
    labels = np.asarray(labels).astype(str)
    codes = pd.factorize(labels)[0]
    key = tuple(codes)
    if key in seen or len(set(codes))>5:
        return
    seen.add(key)
    schemes.append({'name':name,'family':family,'labels':labels,'codes':codes,'rule':rule})

def bins(values, cuts):
    return np.where(np.isnan(values),-1,np.digitize(values,cuts))

add('Ungrouped','baseline',['All']*len(all_events),'All events together')
add('Event type','format',all_events.event_type,'Group by event_type')
team = np.select([all_events.event_type.eq('Sports') | (all_events.event_type.eq('Family') & (features['male']>=.5)),all_events.event_type.eq('Family'),all_events.genre.isin(['Rock','Country'])],['Family Night & Sports','Family Day','Bar'],default='Social')
add('Team four groups','baseline',team,'Sports or Family male>=50%; other Family; Rock/Country; remaining')
pop = team.astype(object).copy()
pop[all_events.genre.eq('Pop')] = 'Pop'
add('Team plus Pop','format',pop,'Team rule with Pop separated into fifth group')
for name,values in features.items():
    for cuts in [[.25],[.4],[.5],[.6],[.75],[.25,.5],[.33,.67],[.5,.75],[.25,.5,.75],[.2,.4,.6]]:
        add(f'{name} bins {cuts}','audience',bins(values,cuts),f'{name} share cut points {cuts}; missing=-1')
    for threshold in [.33,.5,.67]:
        binary=bins(values,[threshold])
        for split,mask in [('Family',all_events.event_type.eq('Family')),('Concert',all_events.event_type.eq('Concert')),('RockCountry',all_events.genre.isin(['Rock','Country']))]:
            labels=np.where(binary==-1,'Missing',np.char.add(np.where(mask,'Yes/','No/'),binary.astype(str)))
            add(f'{split} x {name} at {threshold}','format plus audience',labels,f'{split} boolean crossed with {name}>={threshold}; shared missing group')
for left,right in itertools.combinations(definitions,2):
    a,b = bins(features[left],[.5]),bins(features[right],[.5])
    labels=np.where((a==-1)|(b==-1),'Missing',np.char.add(np.char.add(a.astype(str),'/'),b.astype(str)))
    add(f'{left} x {right}','two audience traits',labels,f'Both shares split at 50%; four combinations plus missing')
day=all_events.day_of_week
weekend=day.isin(['Saturday','Sunday'])
fri_weekend=day.isin(['Friday','Saturday','Sunday'])
evening=all_events.time_of_day.eq('Evening')
add('Time of day','schedule',all_events.time_of_day,'Morning / Afternoon / Evening')
for title,flag in [('Weekend',weekend),('Friday through Sunday',fri_weekend),('Evening',evening)]:
    add(title,'schedule',flag,title+' true or false')
    for name,values in features.items():
        a=bins(values,[.5])
        labels=np.where(a==-1,'Missing',np.char.add(np.where(flag,'Yes/','No/'),a.astype(str)))
        add(f'{title} x {name}','schedule plus audience',labels,f'{title} boolean crossed with {name}>=50%; shared missing group')
    for category in ['Family','Concert','Comedy','Sports']:
        labels=all_events.event_type.astype(str).to_numpy().copy().astype(object)
        mask=all_events.event_type.eq(category)
        labels[mask]=np.where(flag[mask],category+' yes',category+' no')
        add(f'Event type split {category} by {title}','format plus schedule',labels,f'Four event types; split {category} by {title}')
add('Weekday buckets','schedule',day.map({'Monday':'MonTue','Tuesday':'MonTue','Wednesday':'WedThu','Thursday':'WedThu','Friday':'Fri','Saturday':'Sat','Sunday':'Sun'}),'Monday+Tuesday; Wednesday+Thursday; Friday; Saturday; Sunday')
# Arbitrary month-code category partitions are stress tests, with no seasonal interpretation.
month_number=all_events.month_code.str[-1].map(lambda x:ord(x)-ord('A')).to_numpy()
for k in [2,3,4,5]:
    for offset in range(k):
        add(f'Month-code partition {k}/{offset}','month category stress test',(month_number+offset)//k % k,f'Code A=0,...,L=11; floor((code+{offset})/{k}) modulo {k}; no calendar interpretation')

S=len(schemes)
codes=np.array([s['codes'][:n] for s in schemes])
max_groups=5
# Cache training sufficient statistics by scheme, performer, group, and item.
sums=np.zeros((S,len(acts),5,5))
tickets=np.zeros((S,len(acts),5))
for s in range(S):
    for i in range(n):
        sums[s,act_codes[i],codes[s,i]]+=Y[i]
        tickets[s,act_codes[i],codes[s,i]]+=N[i]
total_sum=sums.sum(axis=1)
total_tickets=tickets.sum(axis=1)

def predictions_excluding(excluded,test):
    sy=total_sum-sums[:,excluded].sum(axis=1)
    sn=total_tickets-tickets[:,excluded].sum(axis=1)
    overall=sy.sum(axis=1)/sn.sum(axis=1)[:,None]
    rates=np.divide(sy,sn[:,:,None],out=np.zeros_like(sy),where=sn[:,:,None]>0)
    rates=np.where((sn==0)[:,:,None],overall[:,None,:],rates)
    return rates[np.arange(S)[:,None],codes[:,test]]*N[test][None,:,None]

def metrics(y,p):
    err=p-y
    den=np.abs(y)+np.abs(p)
    return {'WAPE_pct':100*np.abs(err).sum()/y.sum(),'sMAPE_pct':200*np.divide(np.abs(err),den,out=np.zeros_like(err),where=den!=0).mean(),'NRMSE_pct':100*np.sqrt(np.mean(err**2))/y.mean(),'bias_pct':100*err.sum()/y.sum()}

pred=np.zeros((S,n,5))
nested=np.zeros_like(Y)
selections=[]
for outer in range(len(acts)):
    test=np.flatnonzero(act_codes==outer)
    pred[:,test]=predictions_excluding([outer],test)
    losses=np.zeros(S)
    for inner in range(len(acts)):
        if inner==outer:continue
        itest=np.flatnonzero(act_codes==inner)
        ipred=predictions_excluding([outer,inner],itest)
        losses+=np.abs(ipred-Y[itest]).sum(axis=(1,2))
    best=int(losses.argmin())
    nested[test]=pred[best,test]
    selections.append({'performer':acts[outer],'scheme':schemes[best]['name']})
rows=[]
detail=[]
for s,scheme in enumerate(schemes):
    counts=pd.Series(codes[s]).value_counts()
    rows.append({'scheme_id':s,'scheme':scheme['name'],'family':scheme['family'],'rule':scheme['rule'],'groups':len(counts),'min_shows':counts.min(),**metrics(Y,pred[s])})
    for j,item in enumerate(Ydf.columns):detail.append({'scheme_id':s,'item':item,**metrics(Y[:,j],pred[s,:,j])})
ranking=pd.DataFrame(rows).sort_values('WAPE_pct')
ranking.to_csv(OUT/'all_rules_ranked.csv',index=False)
pd.DataFrame(detail).to_csv(OUT/'all_rules_item_errors.csv',index=False)
pd.DataFrame(selections).to_csv(OUT/'nested_choices.csv',index=False)
assignments=[]
for s,scheme in enumerate(schemes):
    for i,event in all_events.iterrows():assignments.append({'scheme_id':s,'event_id':event.event_id,'group':int(scheme['codes'][i])+1,'label':scheme['labels'][i]})
pd.DataFrame(assignments).to_csv(OUT/'all_assignments.csv',index=False)
pd.DataFrame(features).assign(event_id=all_events.event_id).to_csv(OUT/'audience_features.csv',index=False)
best=int(ranking.iloc[0].scheme_id)
out=all_events[['event_id','performer_id','event_type','genre']].copy()
out['group']=schemes[best]['codes']+1
out['label']=schemes[best]['labels']
out.to_csv(OUT/'best_groups.csv',index=False)
summary={'rules_tested':S,'families':ranking.groupby('family').size().to_dict(),'best':ranking.head(12).to_dict('records'),'nested':metrics(Y,nested),'selected_counts':pd.Series([s['scheme'] for s in selections]).value_counts().to_dict(),'metric_winners':{m:ranking.loc[ranking[m].idxmin(),'scheme'] for m in ['WAPE_pct','sMAPE_pct','NRMSE_pct']}}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
# Additional validation designs for every candidate. Performer holdout remains primary.
show_pred=np.zeros_like(pred)
for i in range(n):
    sy=total_sum.copy()
    sn=total_tickets.copy()
    sy[np.arange(S),codes[:,i]]-=Y[i]
    sn[np.arange(S),codes[:,i]]-=N[i]
    overall=sy.sum(axis=1)/sn.sum(axis=1)[:,None]
    rates=np.divide(sy,sn[:,:,None],out=np.zeros_like(sy),where=sn[:,:,None]>0)
    rates=np.where((sn==0)[:,:,None],overall[:,None,:],rates)
    show_pred[:,i]=rates[np.arange(S),codes[:,i]]*N[i]
validation=[]
rng=np.random.default_rng(771)
for repeat in range(20):
    fold_pred=np.zeros_like(pred)
    for excluded in np.array_split(rng.permutation(len(acts)),5):
        test=np.flatnonzero(np.isin(act_codes,excluded))
        fold_pred[:,test]=predictions_excluding(excluded,test)
    for s,scheme in enumerate(schemes):
        validation.append({'scheme_id':s,'validation':'repeated performer five-fold','repeat':repeat,**metrics(Y,fold_pred[s])})
for s,scheme in enumerate(schemes):
    validation.append({'scheme_id':s,'validation':'leave one performer out','repeat':0,**metrics(Y,pred[s])})
    validation.append({'scheme_id':s,'validation':'leave one show out','repeat':0,**metrics(Y,show_pred[s])})
v=pd.DataFrame(validation)
v.to_csv(OUT/'all_validation_runs.csv',index=False)
v.groupby(['scheme_id','validation'])[['WAPE_pct','sMAPE_pct','NRMSE_pct','bias_pct']].mean().reset_index().merge(ranking[['scheme_id','scheme']],on='scheme_id').to_csv(OUT/'three_validation_designs.csv',index=False)
