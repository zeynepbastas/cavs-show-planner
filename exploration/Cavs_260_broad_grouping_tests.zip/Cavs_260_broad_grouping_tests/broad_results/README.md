# Cavs broad grouping experiment

260 distinct assignments tested, each with at most five groups across historical and upcoming shows. This is a broad sampled hypothesis search, not proof of a global optimum. Duplicate assignments were removed. Thresholds and composite scores were chosen as experimental hypotheses, not established behavioral relationships.

Search families: 80 audience-only rules, 87 format/audience combinations, 28 pairs of audience traits, 33 schedule/audience combinations, 9 format/schedule combinations, 5 schedule rules, 14 arbitrary month-code stress tests, and 4 baseline/format rules. Audience features include young, middle-aged and older buyer shares, gender, children, marriage, home ownership, income, wealth, education, and four equal-weight composite scores. All shares use the corresponding demographic dimension denominator. Missing values have a separate group except in the original team rules, where missing gender defaults to Family Day. Missing groups with no training examples fall back to the overall training rate. Sparse demographic coverage is not weighted by reliability.

Three validation designs applied to all 260 schemes

- Leave one performer out. All of a performer's shows are held out together. Primary result for unseen performers.
- Leave one show out. Other shows by the same performer may remain. This is an easier repeat-show scenario and does not estimate strictly new-performer performance.
- Repeated performer five-fold. Randomly divide performers into five folds, hold each fold out, and repeat 20 times with seed 771. Report average metrics across complete repetitions, not an average of predictions.

Three percentage error measures applied overall and by item under primary performer holdout, plus overall in all validation designs

- WAPE = 100 * sum absolute unit errors / sum actual units. Main selection criterion.
- sMAPE = mean of 200 * absolute error / (absolute actual + absolute prediction); zero/zero contributes zero.
- NRMSE = 100 * square root of mean squared error / mean actual units. Emphasizes large errors; may exceed 100%.
- Signed aggregate bias is also reported.

Forecasts use actual final tickets sold times pooled training-group units divided by training-group tickets. Pricing is unchanged. No held-out sales enter training rates. These errors are conditional on final crowd size and do not include attendance forecasting or new-price effects. Group limits constrain complexity but do not ensure accuracy. Correlation is not the ranking criterion because crowd size can create strong correlations despite systematic sales forecast errors.

Best rule on all three metrics and all three validation designs: original team groups with Pop as a fifth group. Apply rules in order: Sports or Family with male share >=50% -> Family Night & Sports; remaining Family -> Family Day; Rock/Country -> Bar; Pop -> Pop; remaining shows -> Social.

Primary errors: WAPE 21.1799%, sMAPE 27.5124%, NRMSE 29.6137%. Reconstructed team baseline: 23.7763%, 29.7586%, 33.0702%. Baseline differs from supplied team summary because this is an independent pooled-rate implementation, not a rerun of the team's latest notebook.

Additional nested check: hold a performer out before choosing the scheme, select by inner performer-holdout absolute error, then evaluate outer predictions. Team plus Pop selected in all 29 folds, producing 21.1799% WAPE. Candidate set includes a rule identified during previous exploration of these same data. Consequently, nested validation cannot erase all prior analyst selection bias. In the earlier, differently composed 160-rule search, the nested selection procedure scored 22.3999% WAPE. Neither is an external future-show test.

Read all_rules_ranked.csv for every rule, family, group count, smallest historical group and metrics. all_rules_item_errors.csv gives primary errors for all 260 x 5 combinations. three_validation_designs.csv gives all candidates' metrics by test design; all_validation_runs.csv retains all 20 repeated runs. all_assignments.csv assigns all 45 shows under every rule. best_groups.csv gives final winner labels. audience_features.csv exposes the features; broad_search.py defines all thresholds, scores and rules. summary.json and nested_choices.csv retain nested results.

Run python broad_search.py from the extracted folder with numpy and pandas installed. Input CSVs are included under data. Outputs are regenerated under broad_results. The two family-related winning groups each represent only three performers, so their independent sample sizes remain small. Incoming E155 is an afternoon Rock show, a schedule absent among historical concerts. Month codes have no calendar order. Prices, final attendance and time-of-day transfer adjustments are outside this experiment.
